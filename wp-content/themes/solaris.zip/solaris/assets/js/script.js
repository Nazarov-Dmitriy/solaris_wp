document.querySelector('form').onsubmit = async e => {
    e.preventDefault();
  
    console.log(2222);
};